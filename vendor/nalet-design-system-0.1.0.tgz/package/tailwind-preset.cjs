// @nalet/design-system — Tailwind preset
//
// GENERATED FILE — do not edit by hand.
// Source of truth: tokens/tokens.json. Regenerate with `node tokens/build.mjs`.
//
// For CONSUMER apps that want the nalet tokens inside their own Tailwind config:
//   // tailwind.config.cjs
//   module.exports = { presets: [require('@nalet/design-system/tailwind')], ... }
//
// borderRadius DEFAULT is 0 to enforce square frames — the brand non-negotiable.
// Icons are the only rounded shape, and that radius is baked into the icon PNGs.

/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
      "bg": "#0B0F19",
      "bg-2": "#0D1117",
      "surface": "#11161F",
      "surface-2": "#161B26",
      "border": "#1F2633",
      "border-2": "#2A3142",
      "fg": "#E6E6E6",
      "fg-2": "#C9D1D9",
      "fg-muted": "#AEB8C2",
      "fg-dim": "#6E7787",
      "cloud-blue": "#58A6FF",
      "cloud-cyan": "#00A4DC",
      "signal-green": "#2EA043",
      "signal-amber": "#F2B233",
      "signal-red": "#F85149",
      },
      fontFamily: {
        mono: ["'JetBrains Mono'","ui-monospace","monospace"],
        sans: ["Inter","system-ui","sans-serif"],
      },
      spacing: {
      "1": "4px",
      "2": "8px",
      "3": "12px",
      "4": "16px",
      "5": "24px",
      "6": "32px",
      "7": "48px",
      "8": "64px",
      "s-1": "4px",
      "s-2": "8px",
      "s-3": "12px",
      "s-4": "16px",
      "s-5": "24px",
      "s-6": "32px",
      "s-7": "48px",
      "s-8": "64px",
      },
      borderRadius: {
        DEFAULT: '0',
        none: '0',
      },
    },
  },
};
